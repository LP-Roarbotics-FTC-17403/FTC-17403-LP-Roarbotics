// package org.firstinspires.ftc.teamcode; /* where is the file located */
// 
// import com.qualcomm.robotcore.eventloop.opmode.OpMode;
// import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
// 
// @Autonomous /* Shows on the Driver Station as an OpMode to select from */
// public class HelloWorld extends OpMode {
//     @Override
//     public void init() {
//         telemetry.addData("Hello", "Jacky :D");
//     }
//     
//     @Override 
//     public void loop() {
//         
//     }
// }
// 
// 
// 
// 
// 