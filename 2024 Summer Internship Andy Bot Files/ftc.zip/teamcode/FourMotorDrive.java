package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class FourMotorDrive{
    private DcMotor m0;
    private DcMotor m1;
    private DcMotor m2;
    private DcMotor m3;
    
    public void init(HardwareMap hardwareMap) {
      m0 = hardwareMap.get(DcMotor.class, "m0");
      m1 = hardwareMap.get(DcMotor.class,"m1");
      m2 = hardwareMap.get(DcMotor.class, "m2");
      m3 = hardwareMap.get(DcMotor.class, "m3");
      
      m2.setDirection(DcMotor.Direction.REVERSE);
    m3.setDirection(DcMotor.Direction.REVERSE);
    
    m3.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    m0.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    m2.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    m1.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
}
     private void setPowers(double m3Power, double m0Power, double m2Power, double m1Power) {
      double largest = 1.0;
      largest = Math.max(largest, Math.abs(m3Power));
      largest = Math.max(largest, Math.abs(m0Power));
      largest = Math.max(largest, Math.abs(m2Power));
      largest = Math.max(largest, Math.abs(m1Power));
      
      m3.setPower(m3Power / largest);
      m0.setPower(m0Power / largest);
      m2.setPower(m2Power / largest);
      m1.setPower(m1Power / largest);
    }
}
